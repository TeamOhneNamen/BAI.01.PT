require_relative "./interactiv.rb"

int = Interactiv.new
int.begruessung("1m", "ft", "j", 1, 5, "km", "p")
int.begruessung("1m", "ft", "n", 1, 5, "km", "p")

