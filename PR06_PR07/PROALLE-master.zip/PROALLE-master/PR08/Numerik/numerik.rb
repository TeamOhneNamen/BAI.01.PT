# Author:: Ferdinand Trendelenburg
# Author:: Thorben Schomacker

class Numerik
  def initialize
    @solution_recursive = 0.0
    @counter = 0
  end

  def solve_iterative(x ,n, i = 1, t = 1)
    if (x.is_a?(Integer))
      x = x.to_f
    end
    if ((x < 0.0) || (x > 2.0))
      raise ArgumentError, "0 < x <= 2"
    else
      @solution_iterative = 0.0
      n.to_i.times { # sum of the term: (((-1)**(i+1)) * (((x - 1) ** i) / i))
        @solution_iterative = @solution_iterative + (((-1)**(i+1)) * (((x - 1) ** i) / i))
        i += 1
      }
      #puts "Solution: #{@solution_iterative} with n: #{n} \ntarget:   #{Math.log(x)}"
      @solution_iterative
    end
  end

  def new_solve_recursive(x, n)
    case 
    when (x.is_a?(Integer))
      x = x.to_f
    when ((x < 0.0) || (x > 2.0))
      raise ArgumentError, "0 < x <= 2"
    when n == 0
      return @solution_recursive
    end
      @solution_recursive = new_solve_recursive(x, n-1) + (((-1)**(n+1))*(((x-1.0)**n)/n))   
  end

  def to_s
    "Lösung: #{@solution_recursive.to_s} ln(2): #{Math.log(2)}"
  end

  def solve_recursive(x, n, i = 1)
    if (x.is_a?(Integer))
      x = x.to_f
    end
    if ((x < 0.0) || (x > 2.0))
      raise ArgumentError, "0 < x <= 2"
    else
      @solution_recursive += (((-1)**(i+1)) * (((x - 1) ** i) / i))

      if @counter < n
        i += 1
        @counter += 1
        solve_recursive(x, n, i)
      else
        #puts "Solution: #{@solution_recursive} with n: #{n} \ntarget:   #{Math.log(x)}"
      end
      @solution_recursive
    end
  end

  def es_gilt(i = 0, n = 1000.0)
    sol = 0.0
    n.to_i.times{sol += (1.0/(2**i))
      i += 1
    }
    puts sol
  end

  def es_gilt_inject
    (0..100).inject(0){|summ , j|
      summ + (1.0/(2 ** j))
    }
  end

  def es_gilt_reduce
    (0..100).reduce(0){|summ , j|
      summ + (1.0/(2 ** j))
    }
  end

end

alg = Numerik.new()
alg.new_solve_recursive(2, 10000)
puts alg
