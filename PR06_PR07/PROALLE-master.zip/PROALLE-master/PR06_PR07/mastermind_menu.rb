require_relative './codebreaker.rb'
require_relative './knuth.rb'
puts "length?"
length = gets.chomp.to_i
puts "length: #{length}"
puts "range?"
range = gets.chomp.to_i
puts "range: #{range}"
puts "create or guess"
game = gets.chomp
raise ArgumentError unless game == "c" || game == "g" || game == "create" || game == "guess" 
if game == "c" || game == "create"
  knuth = Game.new(length, range)
  knuth.fast_knuth
  knuth.possibilities_set
elsif game == "g" || game == "guess"
  cb = Codebreaker.new(length, range)
  cb.main()
end
